CREATE PROCEDURE test_is(IN num INT)
  BEGIN
DECLARE i INT DEFAULT 1;
DECLARE str VARCHAR(26) DEFAULT 'abcdefghijklmnopqrstuvwxyz';
DECLARE startindex INT DEFAULT 1;
DECLARE len INT DEFAULT 1;
WHILE i <= num DO
SET startindex = FLOOR (RAND() * 26 + 1);
SET len = FLOOR(RAND() * (20-startindex+1) + 1 );

INSERT INTO stringcontent(comtent)
VALUES(SUBSTR(str,startindex,len));
SET i = i +1;
END WHILE;


END;
